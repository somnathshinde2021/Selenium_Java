package orangehrmlive.test;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.*;
import orangehrmlive.util.ReusableMethod;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

public class Assign_Leave {
  @SuppressWarnings("deprecation")
@Test(priority=1)
  public void ValidateDefaultDashboard()
  {
	 
	boolean Defaultvalue=  ReusableMethod.driver.findElement(By.xpath("//div/h1[text() ='Dashboard']")).isDisplayed();
	if(Defaultvalue)
	{
		System.out.println("Dashboard tab opened by default");
	Assert.assertTrue(Defaultvalue);
	}
	else
	{
	Assert.assertFalse(Defaultvalue);
	}
		
  }
  
 @Test(priority=2)
  public void validateTabs()
  {
	 List<WebElement> TabValue=ReusableMethod.driver.findElements(By.xpath("//*[@id='mainMenuFirstLevelUnorderedList']/li"));
	 
	 int numberofTabs=TabValue.size();
	 System.out.println("numberofTabs"+numberofTabs);
	 Assert.assertEquals(11, numberofTabs);
	 
		
	
	
  }
  
  @Test(priority=3)
  public void AssignLeave()
  {
	  JavascriptExecutor js = (JavascriptExecutor) ReusableMethod.driver;
	  try {
		  Actions a=new Actions(ReusableMethod.driver);
	 ReusableMethod.driver.findElement(By.xpath("//span[text()= 'Assign Leave']")).click();
	 Thread.sleep(1000);
	 ReusableMethod.driver.findElement(By.name("assignleave[txtEmployee][empName]")).sendKeys("a");
	 Thread.sleep(1000);
	 WebElement name=ReusableMethod.driver.findElement(By.xpath("(//div[@class='ac_results']/ul/li)[3]"));
	 a.moveToElement(name).click().build().perform();
	 
	 WebElement LeaveType=ReusableMethod.driver.findElement(By.xpath("(//select[@name='assignleave[txtLeaveType]']/option)[3]"));
	LeaveType.click();;
	
	 ReusableMethod.selectFromandToDate("2021-01-31","2021-01-01");
	 
	 String expected="To date should be after from date";
	 String Actual=ReusableMethod.driver.findElement(By.xpath("(//span[@class='validation-error'])[3]")).getText();
	 
	 if(expected.endsWith(Actual))
	 {
		 //passing valid date
		 
		 ReusableMethod.selectFromandToDate("2021-05-01","2021-05-11");	 
	 }
	 
	 ReusableMethod.driver.findElement(By.id("assignleave_txtComment")).sendKeys("Reqest for leave");
	 js.executeScript("window.scrollBy(0,1000)");
	 
	 WebElement submit=ReusableMethod.driver.findElement(By.id("assignBtn"));
	 a.moveToElement(submit).click().build().perform();
	 
	 ReusableMethod.driver.findElement(By.xpath("//input[@id='confirmOkButton']")).click();
	 
	 
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		
	
	
  }
  
  
  
  
  
  
  @BeforeTest
  public void beforeTest() throws InterruptedException {
	  try {
		ReusableMethod.loginApplication();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }

  @AfterTest
  public void afterTest() {
	  ReusableMethod.logoutApplication();
  }

  @BeforeSuite
  public void beforeSuite() throws IOException {
	  ReusableMethod.browserIntialization();
  }

  @AfterSuite
  public void afterSuite() {
	 ReusableMethod.driver.quit();
  }

}
