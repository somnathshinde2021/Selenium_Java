package orangehrmlive.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReusableMethod
{
public static WebDriver driver=null;


public static void browserIntialization() throws IOException
{
	String driverPath=getProperty("DriverPath");
	
	System.setProperty("webdriver.chrome.driver", driverPath+"/chromedriver.exe");
	
	driver=new ChromeDriver();
}
public static void loginApplication() throws IOException, InterruptedException
{
	driver.get(getProperty("URL"));
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
	driver.findElement(By.id("txtUsername")).clear();
	driver.findElement(By.id("txtUsername")).sendKeys("Admin");
	driver.findElement(By.xpath("//input[@name='txtPassword']")).clear();
	driver.findElement(By.xpath("//input[@name='txtPassword']")).sendKeys("admin123");
	Thread.sleep(100);
	driver.findElement(By.id("btnLogin")).sendKeys(Keys.ENTER);

}

public static String getProperty(String Parameter) throws IOException
{
	File propfile=new File("Config//Config.properties");
	FileInputStream fis=new FileInputStream(propfile);
	Properties prop=new Properties();
	prop.load(fis);
	String value=prop.getProperty(Parameter);
	return value;
}


public static void selectFromandToDate(String Fromdate,String Todate) 
{
	System.out.println("select From  and To Date");
	 ReusableMethod.driver.findElement(By.id("assignleave_txtFromDate")).clear();
	 ReusableMethod.driver.findElement(By.id("assignleave_txtFromDate")).sendKeys(Fromdate);
	 ReusableMethod.driver.findElement(By.id("assignleave_txtFromDate")).click();
	 
	 ReusableMethod.driver.findElement(By.id("assignleave_txtToDate")).clear();
	 ReusableMethod.driver.findElement(By.id("assignleave_txtToDate")).sendKeys(Todate);
	 ReusableMethod.driver.findElement(By.id("assignleave_txtToDate")).sendKeys(Keys.ENTER);
	 
	 

}

public static void logoutApplication() 
{
	ReusableMethod.driver.findElement(By.xpath("//a[@class='panelTrigger activated-welcome']")).click();
	ReusableMethod.driver.findElement(By.xpath("//a[text()='Logout']")).click();
	
}
}
